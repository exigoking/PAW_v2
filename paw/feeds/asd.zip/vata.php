<?php
function json($from,$message,$time,$subject,$limit)
{
    //echo "arrivals are". $from . $time . $subject . "</br>";
    //echo "starting json </br>";


	$data = array(
    (object)array(
		'sender' => $from,
		'message' => $message,
		'timestamp' => $time,
        'subject' => $subject
    ),

);
	$json_new = json_encode($data);
     //echo $json_new;
    //echo "getting contents </br>";
	$result = file_get_contents('gmail.json');
     //echo $result;

        //echo "starting to decode existing json </br>";
        $difference = "nihera";
		$i = 0;//0 means newest
        if(!empty($result))
        {
            $prev_messages_decoded = json_decode($result);
            //echo "json is not empty </br>";
            if($prev_messages_decoded[0]->timestamp > $data[$i]->timestamp)
            {
                //echo "latest time is:". $prev_messages_decoded[0]->timestamp;
                //echo "arrival time is:". $data[$i]->timestamp;
                //echo "arrived message is new </br>";
                $difference = $data[$i]->message;
                file_put_contents("gmail.json",$json_new);
            }
            else
            {
                //echo "latest time is:". $prev_messages_decoded[0]->timestamp;
                //echo "arrival time is:". $data[$i]->timestamp;
                //echo "arrived message is not new </br>";


            }
        }

        else

        {
            echo "old json is empty </br>";
            $difference = $data[$i]->message;
            file_put_contents("gmail.json",$json_new);
        }




        //return $difference_array;
        echo $difference;
}
?>